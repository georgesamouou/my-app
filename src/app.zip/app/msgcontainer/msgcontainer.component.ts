import { Component } from '@angular/core';

@Component({
  selector: 'app-msgcontainer',
  templateUrl: './msgcontainer.component.html',
  styleUrls: ['./msgcontainer.component.css']
})
export class MsgcontainerComponent {

}
